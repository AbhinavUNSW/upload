#!/bin/bash

# A script to simulate multiple access to the access control

# Init params
all_node=6
request=$1
repeat=$2
provider_type=$3

# Start Here
# if [ "$request" -gt "$all_node" ]; then
#     end_loop=request
# fi

for n in $(seq 1 $request); do
    for i in $(seq 1 $repeat); do
        for j in $(seq 1 $n); do
            if (( j <= all_node )); then
                # echo $j
                acc=0
                ssh raspi_$j "cd bc-iot-auth/rinkeby && venv/bin/python3 main-rinkeby.py $acc $provider_type" >> results/result_${provider_type}_$n.txt &
            else
                # echo "$(( $j - $all_node ))"
                acc=1
                index="$(( $j - $all_node ))"
                ssh raspi_$index "cd bc-iot-auth/rinkeby && venv/bin/python3 main-rinkeby.py $acc $provider_type" >> results/result_${provider_type}_$n.txt &
            fi
        done

        wait
        sleep $[ ( $RANDOM % 7 )  + 1 ]s
    done
done
