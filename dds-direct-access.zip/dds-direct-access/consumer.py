from web3 import Web3
from web3.middleware import geth_poa_middleware
import time
import pickle

DDS_IP_ADDR = '192.168.0.108'
DDS_PORT = 8081
OWN_IP_ADDR = ''

def get_public_key(ip_addr, account_index):
    public_keys = [ "0x0ccA901c9F18cFf95517cC918C935bdee8ac627a",
                    "0xF8A179aE63CEe4d58d23ff37f43cF4882e56a654",
                    "0xc88e4A7173C4E13a59618e99bA76935F9009FcFa",
                    "0x328552F7FB5eA27E895dAFCe63721DFa3E1F66Eb",
                    "0x13e8625f175B87d36e92804a596260907D5173c9",
                    "0xED562D29EA783c8a13b94Ebb0Ce2275b6E98d1ab",
                    "0x59d8a5af4fF5D4b43fa147cc76f740eDe43b45FA",
                    "0xE70b841B0779c042b45f4922742Ca3B7640968e8",
                    "0x6180800Fdc30E2Ad24C72bFf33a17515877c4640",
                    "0x21c434F30a9D529BC51F42bd7592B77fe8a7E7EA",
                    "0xe48C4ae38070E579859713B46868Dfd8de910660",
                    "0x3d05b66704250b72Ce08e045E7F7936cEC44706F"]

    public_key = ''

    if ip_addr == '192.168.0.101': # raspi_1
        public_key = public_keys[account_index]
    elif ip_addr == '192.168.0.103': # raspi_2
        public_key = public_keys[account_index + 2]
    elif ip_addr == '192.168.0.104': # raspi_3
        public_key = public_keys[account_index + 4]
    elif ip_addr == '192.168.0.105': # raspi_4
        public_key = public_keys[account_index + 6]
    elif ip_addr == '192.168.0.106': # raspi_5
        public_key = public_keys[account_index + 8]
    else: # raspi_6
        public_key = public_keys[account_index + 10]

    return public_key

def send_message(dest_host, dest_port, msg):
    soc = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    try:
        soc.connect((dest_host, dest_port))
    except:
        print("Connection error")
        sys.exit()
    
    # send the message in byte format
    soc.sendall(pickle.dumps(msg))
    # wait for response
    ret = soc.recv(5120)
    response = pickle.loads(ret)
    
    return response

def access_dds(w3, provider = 'geth', account_index = 0):
    if provider == 'geth':
        default_account = w3.eth.defaultAccount
    else:
        default_account = get_public_key(OWN_IP_ADDR, account_index)
    
    payload =  {'request': 'access',
                'body': {
                    'sc_key': default_account
            }}

    # send message to attribute authority
    response = send_message(DDS_IP_ADDR, DDS_PORT, payload)
    if response['status'] == 'OK':
        # successful
        # print('Access granted')
        pass
    else:
        # error happened
        print('Access denied')

eth_account = int(sys.argv[1])

w3 = Web3(Web3.HTTPProvider('https://rinkeby.infura.io/v3/cc8b7573a7df47a7ac9ce9c06739b0ba'))
w3.middleware_onion.inject(geth_poa_middleware, layer=0)

# get the ip address of this machine
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.connect(("8.8.8.8", 80))
OWN_IP_ADDR = s.getsockname()[0]
s.close()

## Authorize Direct Access
start_time = time.time()

access_dds(w3, 'infura', eth_account)
elapsed_time = (time.time() - start_time)

print(elapsed_time)