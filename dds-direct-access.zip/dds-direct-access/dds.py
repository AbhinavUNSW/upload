# dds.py
# 1 July 2020

from web3 import Web3
from web3.middleware import geth_poa_middleware
from eth_account.messages import encode_defunct
from eth_utils import decode_hex

import socket
import sys
import traceback
from threading import Thread
import json
import pickle
import time

# HOST = '192.168.0.8'
# HOST = '127.0.0.1'
HOST = '0.0.0.0'
DDS_PORT = 8081
SOCKET_TIMEOUT = 3600

RPC_URL = 'http://127.0.0.1'
RPC_PORT = ':8545'
RPC_PORT_PRIVATE = ':9000'
DEFAULT_ACC = 0

def start_server(host, port, w3_instance, instance_name = '[DEFAULT]', num_listen = 100):
    socket.setdefaulttimeout(SOCKET_TIMEOUT)
    soc = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    soc.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)   # SO_REUSEADDR flag tells the kernel to reuse a local socket in TIME_WAIT state, without waiting for its natural timeout to expire
    # print("{} Socket created".format(instance_name))

    try:
        soc.bind((host, port))
    except:
        print("Bind failed. Error : " + str(sys.exc_info()))
        sys.exit()

    soc.listen(num_listen)       # queue up to 5 requests
    print("{} Socket now listening".format(instance_name))

    # infinite loop- do not reset for every requests
    while True:
        try:
            connection, address = soc.accept()
        except socket.timeout:
            print('No incoming connection. Thread is stopped.')
            sys.exit()
        
        ip, port = str(address[0]), str(address[1])
        # print("{} Connected with {}:{}".format(instance_name, ip, port))

        try:
            Thread(target=client_thread, args=(connection, ip, port, instance_name, w3_instance)).start()
        except:
            print("Thread did not start.")
            traceback.print_exc()

    soc.close()

def client_thread(connection, ip, port, instance_name, w3, max_buffer_size = 5120):
    client_input = connection.recv(max_buffer_size)
    client_input_size = sys.getsizeof(client_input)

    if client_input_size > max_buffer_size:
        print("The input size is greater than expected {}".format(client_input_size))

    decoded_payload = pickle.loads(client_input)
    response = {'status': 'ERR',
                'body': {}
            }
    
    # do something with the payload
    if decoded_payload['request'] == 'access' :
        # wait for blockchain events
        check_for_events(w3, decoded_payload['body']['sc_key'])
        
        response['status'] = 'OK'

    # send response
    connection.sendall(pickle.dumps(response))
    connection.close()

def check_for_events(w3, sc_account):
    # Policy Contract
    with open('smart-contracts/Policy.pk', 'r') as filehandle:
        policy_ctr_address = filehandle.read().strip()
    with open('smart-contracts/Policy.abi', 'r') as filehandle:
        policy_ctr_abi = json.load(filehandle)
    
    policy_ctr = w3.eth.contract(
        address = policy_ctr_address,
        abi = policy_ctr_abi
    )
    
    # Get list of all events
    event_filter = policy_ctr.events.authorized.createFilter(fromBlock=0)
    found = False
    while True:
        events = event_filter.get_all_entries()
        # events = event_filter.get_new_entries()
        length = len(events)
        if length > 0:
            for e in events:
                if e['args']['_scaddr'] == sc_account:
                    print('Event found. Sending auth response...')
                    found = True
                    break
            
            if found == True:
                break

        time.sleep(0.10)

# w3 init
# w3 = Web3(Web3.HTTPProvider(RPC_URL + RPC_PORT))
w3 = Web3(Web3.HTTPProvider('https://rinkeby.infura.io/v3/cc8b7573a7df47a7ac9ce9c06739b0ba'))
w3.middleware_onion.inject(geth_poa_middleware, layer=0)
w3.eth.defaultAccount = w3.eth.accounts[DEFAULT_ACC]

start_server(HOST, DDS_PORT, w3)
